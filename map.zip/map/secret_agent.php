<?php
require_once __DIR__ . '/../inc/env.php';
return [
    'OPENAI_API_KEY' => ttg_env('OPENAI_API_KEY'),
    'OPENAI_MODEL'   => ttg_openai_model(),
    // Historic OS maps on /map (National Library of Scotland via MapTiler). A browser key, free for
    // non-commercial use: in MapTiler, restrict it to timetravellersguild.com. Paste it in place of
    // ttg_env('MAPTILER_KEY', '') below as 'your-key', or put MAPTILER_KEY=your-key in the private .env.
    'MAPTILER_KEY'   => ttg_env('MAPTILER_KEY', ''),
    // Old photographs on /map from Europeana (National Library of Wales and others). Free key from
    // https://pro.europeana.eu/page/get-api . Server-side only: it never reaches the browser.
    // Paste it between the quotes: 'EUROPEANA_KEY' => 'your-key',
    'EUROPEANA_KEY'  => '',
];
